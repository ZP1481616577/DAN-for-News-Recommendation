from model import *
from reader import *
from sklearn import metrics
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "2"


class Inference():
    def __init__(self, size, data_path, item, group, title, save_path):
        self.reader = reader(data_path, item, group, title)
        self.reader.create_dataset()
        self.batch_size = len(self.reader.data)
        self.vocabulary = self.reader.create_vocab()
        self.save_path = save_path
        self.model = model(self.vocabulary, size)
        self.size = size

    def score(self, start):
        config = tf.ConfigProto(allow_soft_placement=True)
        with tf.Session(config=config) as sess:
            X_test, y_test, l_test = self.reader.get_data(start, self.size)
            saver = tf.train.Saver()
            saver.restore(sess, self.save_path)
            predict = np.squeeze(self.model.inference(sess, X_test, y_test))
            f1 = metrics.f1_score(l_test, predict)
            auc = metrics.roc_auc_score(l_test, predict)
            sess.close()
        return f1, auc


if __name__ == "__main__":
    infer = Inference(10000, "./test.txt", "./item.json", "./group.json", "./title.json",
                      "./train_model/mymodel.ckpt-2000")
    F1, auc = infer.score(0)
    print((F1, auc))
