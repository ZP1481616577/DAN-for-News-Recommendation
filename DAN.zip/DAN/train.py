from model import *
import math
from reader import *
import tensorflow as tf
import os
from sklearn import metrics
os.environ["CUDA_VISIBLE_DEVICES"] = "0"


class trainer():
    def __init__(self, validation, data_path, item, group, title, save_path):
        self.batch_size = 80
        self.reader = reader(data_path, item, group, title)
        self.reader.create_dataset()
        self.vocabulary = self.reader.create_vocab()
        self.save_path = save_path
        self.num_epochs = 30
        self.validation = validation
        self.reader_validation = reader(validation, item, group, title)
        self.reader_validation.create_dataset()
        self.max_f1 = 0

    def train(self):
        config = tf.ConfigProto(allow_soft_placement=True)
        with tf.Session(config=config) as sess:
            self.model = model(self.vocabulary)
            sess.run(tf.global_variables_initializer())
            X_train, y_train, l_train = self.reader.get_data(0, len(self.reader.data))
            saver = tf.train.Saver(write_version=tf.train.SaverDef.V2)
            num_iterations = int(math.ceil(1.0 * len(X_train) / self.batch_size))
            for epoch in range(self.num_epochs):
                sh_index = np.arange(len(X_train))
                np.random.shuffle(sh_index)
                X_train = np.array(X_train)[sh_index]
                y_train = np.array(y_train)[sh_index]
                l_train = np.array(l_train)[sh_index]
                print("current epoch: %d" % (epoch))
                total_loss = 0
                for iteration in range(num_iterations):
                    X_batch, y_batch, l_batch = self.reader.get_next_batch(X_train, y_train, l_train, iteration * self.batch_size)
                    loss = self.model.train(sess, X_batch, y_batch, l_batch)
                    total_loss += loss
                    print("iteration: %5d, loss: %.5f, total_loss: %.5f, f1: %.5f" % (
                        iteration, loss, total_loss, self.max_f1))
                    if (epoch * num_iterations + iteration) % 1000 == 0:
                        f1 = 0
                        for c in range(6):
                            X_val, y_val, l_val = self.reader_validation.get_data(c * 80, 80)
                            predict = np.squeeze(self.model.inference(sess, X_val, y_val))
                            f1_ = metrics.f1_score(l_val, predict)
                            f1 = f1 + f1_
                        f1 = f1 / 6
                        if f1 > self.max_f1:
                            saver.save(sess, self.save_path, global_step=epoch * num_iterations + iteration)
                            self.max_f1 = f1
            sess.close()


if __name__ == "__main__":
    Trainer = trainer("./validation.txt", "./train.txt", "./item.json", "./group.json", "./title.json",
                      "./train_model/mymodel.ckpt")
    Trainer.train()
