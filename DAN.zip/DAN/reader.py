import numpy as np
import json

class reader():
    def __init__(self, data_path, item_path, group_path, title_path):
        self.id2news = {}
        self.item_path = item_path
        self.group_path = group_path
        self.title_path = title_path
        self.data_path = data_path
        self.data = []
        self.item_voc = []
        self.group_voc = []
        self.title_voc = []


    def create_vocab(self):
        with open(self.item_path, "r", encoding="utf-8") as f:
            item = json.load(f)
            for i in range(len(item.keys())):
                self.item_voc.append(item[str(i)])
        with open(self.group_path, "r", encoding="utf-8") as f:
            group = json.load(f)
            for i in range(len(group.keys())):
                self.group_voc.append(group[str(i)])
        with open(self.title_path, "r", encoding="utf-8") as f:
            title = json.load(f)
            for i in range(len(title.keys())):
                self.title_voc.append(title[str(i)])
        self.item_voc = np.array(self.item_voc)
        self.group_voc = np.array(self.group_voc)
        self.title_voc = np.array(self.title_voc)
        vocabulary = (self.item_voc, self.group_voc, self.title_voc)
        return vocabulary

    def create_dataset(self):
        with open(self.data_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        for line in lines:
            line = line.strip()
            line = line.split()
            for i in range(len(line)):
                line[i] = int(line[i])
            x = line[1:-1]
            y = line[-1]
            l = line[0]
            if len(line) < 12:
                x = x + [0] * (12 - len(line))
            self.data.append((x, y, l))

    def get_data(self, start_index=0, batch_size=80):
        last_index = start_index + batch_size
        data = self.data[start_index:min(last_index, len(self.data))]
        X_batch = [x[0] for x in data]
        y_batch = [x[1] for x in data]
        l_batch = [x[2] for x in data]
        if last_index > len(self.data):
            left_size = last_index - (len(self.data))
            for i in range(left_size):
                index = np.random.randint(len(self.data))
                X_batch.append(self.data[index][0])
                y_batch.append(self.data[index][1])
                l_batch.append(self.data[index][2])
        X_batch = np.array(X_batch)
        y_batch = np.array(y_batch)
        l_batch = np.array(l_batch)
        return X_batch, y_batch, l_batch

    def get_next_batch(self, X_train, y_train, l_train, start_index, batch_size=80):
        X_train = X_train.tolist()
        y_train = y_train.tolist()
        l_train = l_train.tolist()
        last_index = start_index + batch_size
        X_batch = X_train[start_index:min(last_index, len(X_train))]
        y_batch = y_train[start_index:min(last_index, len(X_train))]
        l_batch = l_train[start_index:min(last_index, len(X_train))]
        if last_index > len(X_train):
            left_size = last_index - (len(X_train))
            for i in range(left_size):
                index = np.random.randint(len(X_train))
                X_batch.append(X_train[index])
                y_batch.append(y_train[index])
                l_batch.append(l_train[index])
        X_batch = np.array(X_batch)
        y_batch = np.array(y_batch)
        l_batch = np.array(l_batch)
        return X_batch, y_batch, l_batch

if __name__ == "__main__":
    pass


