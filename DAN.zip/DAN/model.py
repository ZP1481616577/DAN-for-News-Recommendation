import tensorflow as tf


class model():
    def __init__(self, vocabulary, batch_size=80):
        self.num_selects = 10
        self.num_lstm_layers = 1
        self.item, self.group, self.title = vocabulary
        self.learning_rate = 0.0003
        self.hidden_size = 128
        self.input_size_item = 10 * 8 * 8
        self.input_size_title = 4 * 8 * 8
        self.input_size = self.input_size_item + self.input_size_title
        self.dropout_rate = 0.5
        self.num_word = 160556
        self.embed_size = 50
        self.num_group = 19
        self.num_steps = 10
        self.cnn_out_size = 128
        self.batch_size = batch_size
        self.filter_shape_item = [40, 20, 1, 8]
        self.filter_shape_title = [2, 20, 1, 8]
        self.filter_shape = [2, 8, 1, 4]
        self.cat_size = 7 * 30 * 4
        self.clicks = tf.placeholder(tf.int32, [self.batch_size, self.num_steps])
        self.candidate = tf.placeholder(tf.int32, [self.batch_size])
        self.target = tf.placeholder(tf.int32, [self.batch_size])
        self.word_embedding = tf.get_variable(name="word_embed", shape=[self.num_word + 1, self.embed_size],
                                              dtype=tf.float32, initializer=tf.truncated_normal_initializer(stddev=0.1))
        self.group_embedding = tf.get_variable(name="group_embed", shape=[self.num_group + 1, self.embed_size],
                                               dtype=tf.float32,
                                               initializer=tf.truncated_normal_initializer(stddev=0.1))
        with tf.variable_scope("policy_step"):
            self.cells = []
            for i in range(self.num_lstm_layers):
                lstm_cell = tf.contrib.rnn.LSTMCell(self.hidden_size, use_peepholes=True, state_is_tuple=True)
                lstm_cell = tf.contrib.rnn.DropoutWrapper(lstm_cell, output_keep_prob=self.dropout_rate)
                self.cells.append(lstm_cell)
            self.lstm = tf.contrib.rnn.MultiRNNCell(self.cells, state_is_tuple=True)
        self.output = self.forward()
        self.loss = self.loss_function(self.output)
        self.optimizer = tf.train.AdamOptimizer(learning_rate=self.learning_rate).minimize(self.loss)


    def convolution(self, inputs):
        item_lookup = tf.reshape(tf.nn.embedding_lookup(self.item, inputs), [-1, 40])
        group_lookup = tf.reshape(tf.nn.embedding_lookup(self.group, inputs), [-1, 40])
        title_lookup = tf.reshape(tf.nn.embedding_lookup(self.title, inputs), [-1, 10])
        item_embed = tf.expand_dims(tf.nn.embedding_lookup(self.word_embedding, item_lookup), 2)
        group_embed = tf.expand_dims(tf.nn.embedding_lookup(self.group_embedding, group_lookup), 2)
        item_group_embed = tf.expand_dims(
            tf.reshape(tf.concat((item_embed, group_embed), 2), [-1, 80, self.embed_size]), -1)
        title_embed = tf.expand_dims(tf.nn.embedding_lookup(self.word_embedding, title_lookup), -1)
        with tf.variable_scope("conv-maxpool-item-group", initializer=tf.truncated_normal_initializer(stddev=0.1),
                               reuse=tf.AUTO_REUSE):
            W_item = tf.get_variable(name='W', shape=self.filter_shape_item, dtype=tf.float32,
                                     initializer=tf.contrib.layers.xavier_initializer(uniform=False))
            b_item = tf.get_variable(name='b', shape=[8], dtype=tf.float32)
            conv_item = tf.nn.conv2d(
                item_group_embed,
                W_item,
                strides=[1, 2, 2, 1],
                padding="VALID",
                name="conv")
            h_item = tf.nn.relu(tf.nn.bias_add(conv_item, b_item), name="relu")
            pooled_item = tf.nn.max_pool(
                h_item,
                ksize=[1, 3, 2, 1],
                strides=[1, 2, 2, 1],
                padding='VALID',
                name="pool")
            self.pool_item = tf.reshape(pooled_item, [self.batch_size, -1, self.input_size_item])

        with tf.variable_scope("conv-maxpool-title", initializer=tf.truncated_normal_initializer(stddev=0.1),
                               reuse=tf.AUTO_REUSE):
            W_title = tf.get_variable(name='W', shape=self.filter_shape_title, dtype=tf.float32,
                                      initializer=tf.contrib.layers.xavier_initializer(uniform=False))
            b_title = tf.get_variable(name='b', shape=[8], dtype=tf.float32)
            conv_title = tf.nn.conv2d(
                title_embed,
                W_title,
                strides=[1, 2, 2, 1],
                padding="VALID",
                name="conv")
            h_title = tf.nn.relu(tf.nn.bias_add(conv_title, b_title), name="relu")
            pooled_title = tf.nn.max_pool(
                h_title,
                ksize=[1, 2, 1, 1],
                strides=[1, 1, 2, 1],
                padding='VALID',
                name="pool")
            self.pool_title = tf.reshape(pooled_title, [self.batch_size, -1, self.input_size_title])
        self.pooled = tf.concat((self.pool_item, self.pool_title), -1)
        self.pool = tf.layers.dense(self.pooled, self.cnn_out_size, activation=tf.nn.relu)
        return self.pool


    def convolution_net(self, inputs):
        inputs = tf.expand_dims(inputs, -1)
        with tf.variable_scope("conv-maxpool-net", initializer=tf.truncated_normal_initializer(stddev=0.1),
                               reuse=tf.AUTO_REUSE):
            W = tf.get_variable(name='W', shape=self.filter_shape, dtype=tf.float32,
                                     initializer=tf.contrib.layers.xavier_initializer(uniform=False))
            b = tf.get_variable(name='b', shape=[4], dtype=tf.float32)
            conv= tf.nn.conv2d(
                inputs,
                W,
                strides=[1, 1, 2, 1],
                padding="VALID",
                name="conv")
            h = tf.nn.relu(tf.nn.bias_add(conv, b), name="relu")
            pooled = tf.nn.max_pool(
                h,
                ksize=[1, 3, 3, 1],
                strides=[1, 1, 2, 1],
                padding='VALID',
                name="pool")
            pool = tf.reshape(pooled, [self.batch_size, self.cat_size])
            return pool

    def full_mlp(self, input):
        with tf.variable_scope("MLP_for_full", reuse=tf.AUTO_REUSE):
            hidden = tf.layers.dropout(input, self.dropout_rate)
            output = tf.layers.dense(hidden, self.cnn_out_size, activation=tf.nn.sigmoid)
        return output


    def classifier_net(self, x, y):
        input = tf.concat((x, y), -1)
        hidden = tf.layers.dropout(input, self.dropout_rate)
        output = tf.layers.dense(hidden, 2, activation=tf.nn.sigmoid)
        return output


    def attention(self, prev_state, state, time_steps):
        with tf.variable_scope("attention", initializer=tf.truncated_normal_initializer(stddev=0.1),
                               reuse=tf.AUTO_REUSE):
            w1 = tf.get_variable("attn_w1", [1, 1, self.hidden_size, self.hidden_size], dtype=tf.float32)
            v = tf.get_variable("attn_v", [self.hidden_size], dtype=tf.float32)
            hide = tf.reshape(prev_state, [self.batch_size, time_steps, 1, self.hidden_size])
            hidden_features = tf.nn.conv2d(hide, w1, [1, 1, 1, 1], "SAME")
            w2 = tf.get_variable("attn_w2", [self.hidden_size, self.hidden_size], dtype=tf.float32)
            y = tf.matmul(state, w2)
            y = tf.reshape(y, [self.batch_size, 1, 1, self.hidden_size])
            s = tf.reduce_sum(v * tf.nn.tanh(hidden_features + y), [2, 3])
            a = tf.nn.softmax(s)
            d = tf.reduce_sum(tf.reshape(a, [self.batch_size, time_steps, 1, 1]) * hide, [1, 2])
            attention = tf.reshape(d, [self.batch_size, self.hidden_size])
        return attention


    def attention_net(self, prev_state, state, time_steps):
        with tf.variable_scope("attention_net", initializer=tf.truncated_normal_initializer(stddev=0.1),
                               reuse=tf.AUTO_REUSE):
            w1 = tf.get_variable("attn_w1", [1, 1, self.cnn_out_size, self.cnn_out_size], dtype=tf.float32)
            v = tf.get_variable("attn_v", [self.cnn_out_size], dtype=tf.float32)
            hide = tf.reshape(prev_state, [self.batch_size, time_steps, 1, self.cnn_out_size])
            hidden_features = tf.nn.conv2d(hide, w1, [1, 1, 1, 1], "SAME")
            w2 = tf.get_variable("attn_w2", [self.cnn_out_size, self.cnn_out_size], dtype=tf.float32)
            y = tf.matmul(state, w2)
            y = tf.reshape(y, [self.batch_size, 1, 1, self.cnn_out_size])
            s = tf.reduce_sum(v * tf.nn.tanh(hidden_features + y), [2, 3])
            a = tf.nn.softmax(s)
            d = tf.reduce_sum(tf.reshape(a, [self.batch_size, time_steps, 1, 1]) * hide, [1, 2])
            attention = tf.reshape(d, [self.batch_size, self.cnn_out_size])
        return attention


    def step(self, prev_state, state, inputs, time_steps):
        prev_embedding = tf.squeeze(self.convolution(inputs))
        output, new_state = self.lstm(prev_embedding, state)
        h = new_state[-1][-1]
        atten = self.attention(prev_state, h, time_steps)
        current_state = tf.concat((prev_state, tf.expand_dims(atten, 1)), 1)
        return atten, new_state, current_state


    def forward(self):
        clicks_embedding = self.convolution(self.clicks)
        candidate_embedding = tf.squeeze(self.convolution(self.candidate))
        feature1 = self.attention_net(clicks_embedding, candidate_embedding, self.num_steps)
        inputs = tf.split(self.clicks, self.num_steps, 1)
        embedding = tf.squeeze(self.convolution(inputs[0]))
        init_state = self.lstm.zero_state(batch_size=self.batch_size, dtype=tf.float32)
        h, state = self.lstm(embedding, init_state)
        prev_state = tf.expand_dims(h, 1)
        for time_steps in range(self.num_steps - 1):
            h, state, prev_state = self.step(prev_state, state, inputs[time_steps + 1], time_steps + 1)
        feature2 = self.convolution_net(prev_state)
        concate = tf.concat((feature2, feature1), -1)
        out = self.full_mlp(concate)
        output = self.classifier_net(out, candidate_embedding)
        return output


    def loss_function(self, output):
        y_true = tf.one_hot(tf.squeeze(self.target), 2)
        total_loss = -tf.reduce_sum(y_true * tf.log(tf.nn.softmax(output) + 0.00000000001), -1)
        loss = tf.reduce_mean(total_loss)
        return loss


    def train(self, sess, X_batch, y_batch, l_batch):
        loss, _ = sess.run([
            self.loss,
            self.optimizer
        ],
            feed_dict={
                self.clicks: X_batch,
                self.candidate: y_batch,
                self.target: l_batch
            })
        return loss


    def inference(self, sess, X_batch, y_batch):
        label = tf.cast(tf.argmax(self.output, 1), tf.int32)
        out = sess.run([
            label
        ],
            feed_dict={
                self.clicks: X_batch,
                self.candidate: y_batch
            })
        return out


if __name__ == "__main__":
    pass
